
<?php
include "config.php";
include "refresh_prevent.js";
// Starting the session, to use and 
// store data in session variable 
session_start(); 
$user=$_SESSION['username'];
date_default_timezone_set('Asia/kolkata');

// If the session variable is empty, this 
// means the user is yet to login 
// User will be sent to 'login.php' page 
// to allow the user to login 
if (!isset($_SESSION['username'])) { 
	$_SESSION['msg'] = "You have to log in first"; 
	header('location: login tutor.php'); 
} 

// Logout button will destroy the session, and 
// will unset the session variables 
// User will be headed to 'login.php' 
// after loggin out 
if (isset($_GET['logout'])) { 

$g=mysqli_query($db,"UPDATE users set current_class='0',work_id='0',att_id='0',internal=NULL where Login_id='$user'");


	session_destroy(); 
	unset($_SESSION['username']); 
	header("location: login tutor.php"); 
} 
?> 



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css homepage.css">

<style>

.header {
  padding: 0.1px;
  text-align: center;
  background: url("yellow.JPG") fixed;
  color: rgba(179, 9, 9, 0.932);
 font-size: 15px;
 
}
body {font-family: Arial, Helvetica, sans-serif;}

</style>

</head>
<body>


<!-- Creating notification when the 
				user logs in -->
		
		<!-- Accessible only to the users that 
				have logged in already -->
        <?php if (isset($_SESSION['success'])) : ?> 
			<div class="error success" > 
				<h3> 
					<?php
						//echo $_SESSION['success']; 
						unset($_SESSION['success']); 
					?> 
				</h3> 
			</div> 
		<?php endif ?> 


  <div class="header">


  <?php if (isset($_SESSION['username'])) : ?> 
    <p align="left"> <font color="black"
    ><b> Hi
     <?php echo $_SESSION['username'].". Welcome to the class, as a Tutor"; ?>   
   </b></font> </p>


    <p align="right"><a href="TU_HOMEPAGE NEW.php?logout='1'"><b><font size="5px">LogOut</font></b></a>&nbsp;&nbsp;&nbsp;</p>
    <h1><b>--Class Management--</b></h1>
    <p></p>
  </div>
  <?php endif ?> 


<div class="navbar">
  <a href="profile tutor.php">My Profile</a>
  <a href="student info.php">Students</a>
<a href="Teacher info.php">Teachers</a>
  <div class="subnav">
    <button class="subnavbtn" name="button10">Lecture Scheduling <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content1">
      <a href="LECTURE SCHEDULING upload.php">Schedule</a>
      <a href="Lecture  view_tutor.php">See Scheduled Lecture</a>
      
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn" name="button10">Syllabus <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content2">
      <a href="Sylabus&books tutor view.php">View </a>
      <a href="Sylabus&books upload.php">Upload</a>
      <!--<a href="edit sylabus&books.php">edit</a>-->
      
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn" name="button10">Works&Internal<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content3">
      <a href="studentWorks upload.php">Upload</a>
      <a href="see works_teacherview.php">see Works</a>
      
      
    </div>
  </div>



<div class="subnav">
    <button class="subnavbtn" name="button10">Attendence<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content4">
      <a href="Attendence Tutor upload.php">Upload</a>
      <a href="see attendence_teacherview.php">see Attendence</a>
      
    </div>
  </div>

<a href="request_.php">Messages</a>
<a href="message.php">Broadcast</a>
<a href="settings_tutor.php">Settings</a>
</div>
</center>

<div style="padding:0 16px">


  <br><br>
</div>

</body>
</html>

