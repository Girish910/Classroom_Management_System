<?php

include 'config.php';
session_start(); 

if (!isset($_SESSION['username1'])) { 
	$_SESSION['msg'] = "You have to log in first"; 
	header('location: login tutor.php'); 
} 

$id=$_SESSION['username1'];
$query="select photo_type,photo from teacher where Login_id='$id'";
$result=mysqli_query($db,$query);
$row = mysqli_fetch_array($result);
header("Content-type: " . $row["photo_type"]);
echo $row["photo"];

?>